import React,{useEffect,useMemo,useState} from 'react';
import {Search,Play,ArrowUpRight,Heart,Grid2X2,X,Gamepad2,CloudOff} from 'lucide-react';
import {useGame} from '../context/GameContext';
import {usePlayer} from '../context/PlayerContext';
import {useLauncher} from '../launcher/LauncherContext';
import {normalizeSearch} from '../launcher/catalog';
import {GameArtwork} from '../visuals/gameArt';
import {LazyGameCard} from './common/LazyGameCard';
const categories=[['Tất Cả','Tất cả'],['Yêu Thích','Yêu thích'],['Puzzle','Giải đố'],['Arcade','Arcade'],['Action','Hành động'],['Reflex','Phản xạ'],['Multiplayer','Đối kháng']];
const initialFilter=()=>{try{return JSON.parse(sessionStorage.getItem('launcher_library_filter')||'{}');}catch{return {};}};
export const GameCatalog:React.FC=()=>{
 const {launchGame,openGameDetail,favorites,toggleFavorite,recentlyPlayed}=useGame();const {profile}=usePlayer();const {catalog,source,refresh}=useLauncher();
 const [category,setCategory]=useState(initialFilter().category||'Tất Cả');const [query,setQuery]=useState(initialFilter().query||'');
 useEffect(()=>{try{sessionStorage.setItem('launcher_library_filter',JSON.stringify({category,query}));}catch{}},[category,query]);
 useEffect(()=>{const select=(e:Event)=>{setCategory((e as CustomEvent<string>).detail);setQuery('');};window.addEventListener('arcadex:filter_games',select);return()=>window.removeEventListener('arcadex:filter_games',select);},[]);
 const filtered=useMemo(()=>catalog.games.filter(game=>{
  const matches=category==='Tất Cả'||category==='Yêu Thích'&&favorites.includes(game.id)||category==='Multiplayer'&&(game.category==='Multiplayer'||game.supportsAI)||game.category===category;
  return matches&&normalizeSearch([game.title,game.shortDesc,...game.tags].join(' ')).includes(normalizeSearch(query));
 }),[catalog,category,query,favorites]);
 const recent=recentlyPlayed.map(id=>catalog.games.find(game=>game.id===id)).filter(Boolean).slice(0,3);
 const featured=catalog.games.find(game=>game.featured&&game.availability==='published'&&game.accessModel==='free')||catalog.games[0];
 const reset=()=>{setQuery('');setCategory('Tất Cả');};
 return <div className="launcher-catalog arcade-catalog simple-catalog">
  <section className="launcher-welcome"><div><p className="launcher-eyebrow">KHOẢNG NGHỈ CỦA BẠN</p><h1>Chơi một chút.<br/><span>Vui cả ngày.</span></h1><p>Game nhỏ, niềm vui lớn. Chọn một trò và bắt đầu thôi.</p><a className="launcher-primary" href="#game-library"><Grid2X2 size={18}/>Khám phá thư viện</a></div>
   {featured&&<div className="welcome-game"><div className="welcome-sticker">HÔM NAY CHƠI GÌ?</div><button className="welcome-art" onClick={()=>openGameDetail(featured.id)} aria-label={`Khám phá ${featured.title}`}><GameArtwork gameId={featured.id}/></button><div className="welcome-caption"><div><span>GỢI Ý CHO BẠN</span><h2>{featured.title}</h2></div><button id="btn-launch-featured" aria-label={`Chơi game nổi bật ${featured.title}`} className="launcher-icon" onClick={()=>launchGame(featured.id)}><Play size={22} fill="currentColor"/></button></div></div>}
  </section>
  <div className="launcher-benefits"><span><Gamepad2 size={17}/>Chọn game và chơi ngay</span><span><Heart size={17}/>Lưu những trò bạn thích</span><span><CloudOff size={17}/>Game đơn hỗ trợ chơi offline</span></div>
  {recent.length>0&&<section id="recent-games" className="launcher-recents" aria-labelledby="heading-recently-played"><div className="launcher-section-title"><h2 id="heading-recently-played">Chơi gần đây</h2><span>Quay lại trò bạn thích</span></div><div>{recent.map(game=><button key={game!.id} id={`btn-play-recent-${game!.id}`} onClick={()=>launchGame(game!.id)}><div><GameArtwork gameId={game!.id}/></div><span>{game!.title}</span><ArrowUpRight size={19}/></button>)}</div></section>}
  <section id="game-library" className="launcher-library" aria-labelledby="heading-game-library">
   <div className="launcher-section-title"><div><p className="launcher-eyebrow">TÌM NIỀM VUI MỚI</p><h2 id="heading-game-library">Thư viện game <span>({filtered.length})</span></h2></div><label className="launcher-search"><Search size={19}/><input id="input-search-games" aria-label="Tìm trò chơi" placeholder="Bạn muốn chơi gì?" value={query} onChange={e=>setQuery(e.target.value)}/>{query&&<button aria-label="Xóa tìm kiếm" onClick={()=>setQuery('')}><X size={17}/></button>}</label></div>
   <div className="launcher-categories" aria-label="Thể loại game">{categories.map(([id,label])=><button id={`btn-filter-${id.toLowerCase().replace(/\s+/g,'-')}`} key={id} aria-pressed={category===id} aria-label={id==='Tất Cả'?'Tất Cả Game':label} onClick={()=>setCategory(id)}>{id==='Yêu Thích'&&<Heart size={15}/>} {label}</button>)}</div>
   {source==='device'&&<p className="launcher-local-note">Thư viện trên thiết bị <button onClick={()=>void refresh()}>Làm mới</button></p>}
   {filtered.length?<div className="cartridge-grid">{filtered.map(game=><LazyGameCard key={game.id} game={game} personalHighScore={profile.stats.highScores[game.id]||0} isFav={favorites.includes(game.id)} onOpenDetail={openGameDetail} onToggleFavorite={toggleFavorite} onLaunchGame={launchGame}/>)}</div>:<div className="launcher-empty"><Search size={34}/><h3>{category==='Yêu Thích'?'Chưa có trò chơi yêu thích':'Không tìm thấy trò chơi phù hợp'}</h3><p>{category==='Yêu Thích'?'Chạm vào trái tim trên thẻ game để lưu vào đây.':'Thử từ khóa khác hoặc xem lại toàn bộ thư viện.'}</p><button id="btn-show-all-games" className="launcher-primary" onClick={reset}>Xem tất cả game</button></div>}
  </section>
 </div>;
};
