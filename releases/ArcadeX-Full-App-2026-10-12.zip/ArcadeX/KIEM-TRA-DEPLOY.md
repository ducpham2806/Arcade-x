# Kiểm tra sau khi deploy

1. Mở website HTTPS: splash kết thúc, màn hình chọn Đăng ký/Đăng nhập/Chơi khách hiện trước launcher.
2. Chơi khách, mở mỗi game từ launcher. Thử kéo/thả trong Xếp Gạch và Shikaku, quay lại launcher và tiếp tục ván.
3. Đăng ký bằng email. Xác nhận email nếu bật, đăng nhập và đặt tên hiển thị. Thử tên đã dùng để kiểm tra báo trùng.
4. Chơi một màn rồi tải lại trang: tài khoản và tiến trình phải được khôi phục. Đăng xuất để trở về dữ liệu khách riêng.
5. Shikaku: mở Hành trình, hoàn thành bài 1, xem bài 2 được mở; thử daily và gợi ý giải thích trước khi hiện khung.
6. Với tài khoản đã đăng nhập: kiểm tra xếp hạng Car Escape, Word Cross, Cosmic Defend và Shikaku. Nếu hiển thị luyện tập/chưa kết nối, kiểm tra SQL và function tương ứng trong Supabase.
7. Mở website một lần online, đợi tải xong asset, rồi ngắt mạng và tải lại: launcher và các game đã cache phải tiếp tục mở. Đồng bộ online cần mạng trở lại.
8. Thử cài PWA nếu trình duyệt hỗ trợ. Khi có bản mới, theo hướng dẫn cập nhật ở launcher.

Các cấu hình hosting quan trọng:

- `index.html` phải ở gốc thư mục publish.
- Deploy qua HTTPS; tránh giữ `sw.js` trong cache cố định.
- Không dùng `file://` để chạy website bằng cách mở trực tiếp index.html.
- Đặt đúng Site URL/Redirect URLs của Supabase theo tên miền cuối cùng.
- Nếu gặp lỗi, ghi lại URL đang mở, game/thao tác và thông báo lỗi; không gửi mật khẩu hoặc khóa quản trị.
